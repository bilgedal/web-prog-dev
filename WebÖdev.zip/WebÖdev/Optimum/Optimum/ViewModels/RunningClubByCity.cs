﻿using Optimum.Models;

namespace Optimum.ViewModels
{
    public class RunningClubByCity
    {
        public List<City> Cities { get; set; } = null;
    }
}
