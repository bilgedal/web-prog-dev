﻿using Optimum.Models;

namespace Optimum.ViewModels
{
    public class RunningClubByState
    {
        public List<State> States { get; set; } = null;
    }
}
