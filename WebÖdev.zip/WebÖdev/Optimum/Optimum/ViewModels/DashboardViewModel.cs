﻿using Optimum.Models;

namespace Optimum.ViewModels
{
    public class DashboardViewModel
    {
        public List<Race> Races { get; set; }
        public List<Club> Clubs { get; set; }
    }
}
