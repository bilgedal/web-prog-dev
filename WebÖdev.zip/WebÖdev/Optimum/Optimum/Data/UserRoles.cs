﻿namespace Optimum.Data
{
    public static class UserRoles
    {
        public const string Admin = "admin";
        public const string User = "user";
    }
}
