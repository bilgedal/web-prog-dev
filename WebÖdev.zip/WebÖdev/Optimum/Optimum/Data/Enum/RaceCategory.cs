﻿namespace Optimum.Data.Enum
{
    public enum RaceCategory
    {
        Marathon,
        Ultra,
        FiveK,
        TenK,
        HalfMarathon
    }
}