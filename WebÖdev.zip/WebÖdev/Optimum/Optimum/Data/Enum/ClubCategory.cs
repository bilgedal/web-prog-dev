﻿namespace Optimum.Data.Enum
{
    public enum ClubCategory
    {
        RoadRunner,
        Womens,
        City,
        Trail,
        Endurance
    }
}
